#ifdef __CINT__
#include "Point.h"
#include "Particle.h"
#include "Event.h"
#pragma link off all globals;
#pragma link off all classes;
#pragma link off all functions;

#pragma link C++ class Point+;
#pragma link C++ class Particle+;
#pragma link C++ class Event+;
#pragma link C++ class ParticleTree+;
#endif
