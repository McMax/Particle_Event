#!/bin/bash
vim -p src/Particle.cpp src/Event.cpp src/ParticleTree.cpp src/Point.cpp inc/Particle.h inc/Event.h inc/ParticleTree.h inc/Point.h inc/linkdef.h Makefile
